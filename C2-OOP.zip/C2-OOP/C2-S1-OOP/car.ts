
class Car {
    brand:string;
    price:number;
    electriction: boolean;

    constructor(brand:string, price:number, electriction:boolean){
        this.brand = brand
        this.price = price
        this.electriction = electriction
    }
    rider(){
        console.log("Hello world ", this.brand);
        
    }
}

let hondaCivic = new Car("Honda", 300, false)
hondaCivic.rider()
console.log(hondaCivic);
