
class BankAccount{
  balance: number;
  name: string;
  
  constructor(name: string){
    this.name = name;
    this.balance =0;
  };
  
  credit(valueDollars: number) {
    // TODO : add the valueDollars to the account
    this.balance += valueDollars;
  } 
  
  
  debit(valueDollars: number) {
     // TODO : remove the valueDollars to the account
     this.balance -= valueDollars;
  }
};



// ----------------------------------
//	TEST ZONE
// ----------------------------------


let thonAccount = new BankAccount("Thon py");

// console.log(thonAccount.name + ", your account balance is" + thonAccount.balance);

// credit(thonAccount, 400)

console.log(thonAccount.name + ", your account balance is" + thonAccount.balance);


