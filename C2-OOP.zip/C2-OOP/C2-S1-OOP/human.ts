

class Human {
    nationality: string;
    gender:string;
    age: number;
    name: string;
    constructor(name:string, gender:string, age:number, nationality:string){
        this.name = name
        this.gender = gender
        this.age = age
        this.nationality = "Khmer"
    }
}



let humanCreater = new Human("Tim", "Male", 20, "Khmer")

console.log(humanCreater);
