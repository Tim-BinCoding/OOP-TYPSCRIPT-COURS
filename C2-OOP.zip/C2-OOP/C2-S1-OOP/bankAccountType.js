var BankAccount = /** @class */ (function () {
    function BankAccount(name) {
        this.name = name;
        this.balance = 0;
    }
    ;
    BankAccount.prototype.credit = function (valueDollars) {
        // TODO : add the valueDollars to the account
        this.balance += valueDollars;
    };
    BankAccount.prototype.debit = function (valueDollars) {
        // TODO : remove the valueDollars to the account
        this.balance -= valueDollars;
    };
    return BankAccount;
}());
;
// ----------------------------------
//	TEST ZONE
// ----------------------------------
var thonAccount = new BankAccount("Thon py");
// console.log(thonAccount.name + ", your account balance is" + thonAccount.balance);
// credit(thonAccount, 400)
console.log(thonAccount.name + ", your account balance is" + thonAccount.balance);
