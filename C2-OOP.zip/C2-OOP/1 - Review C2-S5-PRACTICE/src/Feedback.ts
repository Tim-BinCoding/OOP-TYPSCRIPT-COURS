
import { Customer } from "./Customer";

export class Feedback {
  constructor(
    private customer: Customer,
    private comment: string,
    private score?: number
  ) {}

  /**
   * 
   * @returns customer
   */
  getCustomer() {
    return this.customer;
  }
  /**
   * 
   * @returns get comment
   */
  getComment() {
    return this.comment;
  }
  getScore() {
    return this.score;
  }
}
