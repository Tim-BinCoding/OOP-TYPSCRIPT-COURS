import { Feedbacks } from "./Feedback";
export class Products{
    name:string;
    price:number;
    feedbacks:Feedbacks[]=[];
    constructor(n:string, pr:number){
        this.name = n;
        this.price = pr;
    }
    addFeedback(feed:Feedbacks){
       return this.feedbacks.push(feed);
    }
}