
export class Customers{
    firstname:string;
    lastname:string;
    constructor(fName:string, lName:string){
        this.firstname=fName;
        this.lastname=lName;
    }
}



