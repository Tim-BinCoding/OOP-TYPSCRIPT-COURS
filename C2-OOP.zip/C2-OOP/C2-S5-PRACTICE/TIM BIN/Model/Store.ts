
import { Products } from "./Product";
import { Customers } from "./Customer";
export class Stores{
    name:string;
    products:Products[]=[];
    customers:Customers[]=[]
    constructor(n:string){
        this.name = n;
    }
    addProduct(product:Products){
        this.products.push(product);
    }
    addCustomer(customer:Customers){
        this.customers.push(customer);
    }
    getProductLessThan(pricePro:number){
        let listOfpro:Products[]=[]
        let products = this.products
       for (let index = 0; index < products.length; index++) {
           if(products[index].price<=pricePro){
                listOfpro.push(products[index])
           }
       }
       return listOfpro;
    }

    getFeedbackCOntaining(keyword:string){
        let getFeedbacks=[]
        let products=this.products
        for (let index = 0; index < products.length; index++) {
           let feedback=products[index].feedbacks
           for (let n = 0; n < feedback.length; n++) {
               if(feedback[n].comment==keyword){
                   getFeedbacks.push(feedback)
               }
           }
            return getFeedbacks;
        }
    }

    getCustomerComments(customer:string){
        let getComments:string[]=[]
        let products=this.products
        for (let index = 0; index < products.length; index++) {
           let myfeedbacks=products[index].feedbacks
           for (let n = 0; n < myfeedbacks.length; n++) {
               if(myfeedbacks[n].customer.firstname==customer || myfeedbacks[n].customer.lastname==customer){
                    getComments.push(myfeedbacks[n].comment)
               }
           }
        }
        return getComments;
    }
}

