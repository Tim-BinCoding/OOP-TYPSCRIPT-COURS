
import { Customers } from "./Customer";

export class Feedbacks{
    comment:string;
    evaluation: number;
    customer:Customers;
    constructor(com:string, evaluate:number, user:Customers){
        this.comment = com;
        this.evaluation = evaluate;
        this.customer = user;
    }
}