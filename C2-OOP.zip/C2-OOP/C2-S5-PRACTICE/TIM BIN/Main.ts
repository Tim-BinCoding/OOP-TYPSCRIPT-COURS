import { Customers } from "./Model/Customer";
import { Feedbacks } from "./Model/Feedback";
import { Products } from "./Model/Product";
import { Stores } from "./Model/Store";

// add customer
let cus1 = new Customers("Nga", "H")
let cus2 = new Customers("Vansoz", "Hng")

// add feedback
let feedb1 = new Feedbacks("Good product", 90, cus1)
let feedb3 = new Feedbacks("Good product", 96, cus2)
let feedb2 = new Feedbacks("The best product", 100, cus1)

// add product
let pro1 = new Products("Manog", 2000)
pro1.addFeedback(feedb1)
pro1.addFeedback(feedb3)
let pro2 = new Products("Banana", 2500)
pro2.addFeedback(feedb2)

// add stroe
let store1 = new Stores("NH");
store1.addProduct(pro1);
store1.addProduct(pro2);
store1.addCustomer(cus1);
store1.addCustomer(cus2);
// get all product that there are price less than user input
console.log("Product price less than: ", store1.getProductLessThan(3000));
// get all feedbacks contain by key word
console.log("All feedbacks there are:  ", store1.getFeedbackCOntaining("Good product"));
// get all comment from user
console.log("All comment from user there are: ", store1.getCustomerComments("Nga"))

//  

