// TODO  :
import { School } from "./School";
import { Student } from "./Student";
import { Director } from "./Director";

//  1- UPdate the classes to mange
//          - a schoo has many students
//          - as school has 1 director

// 2 - Create a school with a director, and students

let mySchool = new School("Phnom Penh")
let student1 = new Student("Tim Bin")
let student2 = new Student("Bopha Sovann")
mySchool.addStudent(student1)
mySchool.addStudent(student2)
let director = new Director("Khey");
mySchool.director=director

console.log(mySchool);

