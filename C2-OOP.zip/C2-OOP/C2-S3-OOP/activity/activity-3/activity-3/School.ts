import { Student } from "./Student";
import { Director } from "./Director";
export class School {
  city: string;
  students:Student[]=[];
  director:Director={"name": ""};
  addStudent(student:Student){
    this.students.push(student)
  }
  constructor(city: string) {
    this.city = city;
  }
}
