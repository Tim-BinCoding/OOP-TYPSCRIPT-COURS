import { Door } from "./Door";
export class Room {
  name: string;
  doors:Door[]=[]

  addDoor(door:Door){
    this.doors.push(door)
  }

  constructor(name: string) {
    this.name = name;
  }
}
