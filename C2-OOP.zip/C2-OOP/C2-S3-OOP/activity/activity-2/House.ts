
import { Door } from "./Door";
import { Room } from "./Room";

export class House {
  name: string;
  doors:Door[]=[];
  rooms:Room[]=[];

  constructor(name: string) {
    this.name = name;
  }
}

