
class Countries {
    name:string
    population:number
    capital:string
    currency:string
    constructor(name:string, population:number, capital:string, currency:string){
    this.name=name,
    this.population=population,
    this.capital=capital
    this.currency=currency}
    getInformation(){
        console.log("Wellcom to "+ this.name + ", " + this.population + " million people, capital " +this.capital + " and currency "+this.currency);
    }
}

let myCountry1 = new Countries("Frence", 70, "Paris", "Euro")
let myCountry2 = new Countries("Cambodia", 17, "Phnom Penh", "Reil")
let myCountry3 = new Countries("UK", 80, "London", "Pound")
myCountry1.getInformation()
myCountry2.getInformation()
myCountry3.getInformation()




    