
class WepAlumni {
    ExperienceInVueJS:number;
    ExperienceInVueNodeJS:number;
    CancodeOOP:boolean;
    Salary:number;
    constructor(VueJS:number,NodeJS:number, CancodeOOP:boolean,Salary:number){
        this.ExperienceInVueJS = VueJS,
        this.ExperienceInVueNodeJS = NodeJS,
        this.CancodeOOP = CancodeOOP,
        this.Salary = Salary
    }
    getSalary(){
        if ((this.ExperienceInVueJS<1 || this.ExperienceInVueNodeJS<1) && this.CancodeOOP){
            return 250
        }if ((this.ExperienceInVueJS<2 || this.ExperienceInVueNodeJS<2) && this.CancodeOOP){
            return 350
        }else if ((this.ExperienceInVueJS>=2 || this.ExperienceInVueNodeJS>=2) && this.CancodeOOP==false){
            return 450
        }else if ((this.ExperienceInVueJS>=2 || this.ExperienceInVueNodeJS>=2) && this.CancodeOOP){
            return 700
        }
    }
}
let test = new WepAlumni(2, 2, false, 700)

console.log(test.getSalary());


