
import { Address } from "./model/Address";
import { Customer } from "./model/Customer";
import { Trip } from "./model/Trip";
import { Timer } from "./model/DataTime"

// address
let cambodia = new Address("Cambodia", "Phnom Penh");
let komPot = new Address("Kompot", "Kom Peng")
let preahVihear = new Address("Preah Vihear", "Chey san")
let kompongThom = new Address("Kompong Thom", "Kom pungtmors")
// timer
let Time = new Timer("Monday 02-05-2022: 10:30 AM", "Tuesday 12-05-2022: 11:30 AM")

// have a trip
let trip1 = new Trip("Auto_Bus", cambodia, preahVihear, Time);
// list customers to trip
let customer1 = new Customer("Tim", "B")
let customer2 = new Customer("Thy", "Ta")
let customer3 = new Customer("Tang", "Tuy")
let customer4 = new Customer("Tam", "Tok")

customer1.address=komPot;
customer3.address=kompongThom;
trip1.addCustomer(customer1)
trip1.addCustomer(customer2)
trip1.addCustomer(customer3)
trip1.addCustomer(customer4)

console.log(trip1.tripInformation());




