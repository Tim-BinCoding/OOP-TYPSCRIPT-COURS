

export class Timer{
    startTime: string;
    endTime: string;
    constructor(start:string, end:string){
        this.endTime = end;
        this.startTime = start;
    }
}
