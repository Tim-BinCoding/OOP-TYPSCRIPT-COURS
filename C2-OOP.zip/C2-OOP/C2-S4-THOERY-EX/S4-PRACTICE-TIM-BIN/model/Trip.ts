import { Address } from "./Address";
import { Customer } from "./Customer";
import { Timer } from "./DataTime";
export class Trip{
    listCustomers:Customer[]=[];
    busName:string;
    departure: Address;
    arrival: Address;
    timer:Timer
    constructor(bus:string, dep:Address, arrival:Address, time:Timer){
        this.busName = bus;
        this.departure = dep;
        this.arrival = arrival;
        this.timer = time;
    }

    addCustomer(customer:Customer){
        this.listCustomers.push(customer)
    }

    tripInformation(){
        let customers = this.listCustomers;
        let infor = "";
        customers.forEach(element => {
            if(element.address){
                infor+="Customer "+ element.firstname + " " + element.lastname + " come from "+element.address.city + " "+element.address.country + "\n";  
            }else{
                infor+="Customer "+ element.firstname + " " + element.lastname +"\n";
            }
        });
        return infor;
    }

}