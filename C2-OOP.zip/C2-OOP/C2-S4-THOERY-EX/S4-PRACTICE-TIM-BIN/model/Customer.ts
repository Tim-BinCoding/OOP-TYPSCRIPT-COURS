import { Address } from "./Address";

export class Customer {
   firstname: string;
   lastname: string;
    address?: Address;
   constructor(fname:string, lname:string){
       this.firstname = fname;
       this.lastname = lname;
   };
}