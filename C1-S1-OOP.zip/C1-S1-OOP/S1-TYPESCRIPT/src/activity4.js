function addNumber(a, b) {
    return a + b;
}
console.log(addNumber(5, 5));
