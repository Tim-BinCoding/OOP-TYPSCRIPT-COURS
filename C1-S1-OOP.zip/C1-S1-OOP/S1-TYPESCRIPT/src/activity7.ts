
let sun: { name: string; age : number }
= { name: "vun", age: 17 }
let som: { name: string; age : number }
= { name: "sao", age: 48 }