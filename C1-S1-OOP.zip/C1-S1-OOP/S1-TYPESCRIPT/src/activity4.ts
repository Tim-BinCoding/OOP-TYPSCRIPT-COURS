
function addNumber(a:number, b:number){

    return  a+b
}
console.log(addNumber(5, 5));


