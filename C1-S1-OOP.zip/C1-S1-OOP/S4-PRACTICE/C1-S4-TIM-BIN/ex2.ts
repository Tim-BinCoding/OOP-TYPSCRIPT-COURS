/*
 INSTRUCTIONS

	Note : read extra explanation of PDF 
	
	We want to model   Menu and   MenuItem

  	- An Menu has:
			- the menu label (string)
			- the list of menu items (array of MenuItem)


  	- An menuItem has:
			- the menu item label (string)
			- the callBack function called when click (string)

	Q1 : Create the 2 types.

	Q2 : Create the following menus :
				menu File
						label : "File"
						items : 
							name: "Save ...", callBack: "onClickSave" 
							name: "Open...", callBack: "onClickOpen" 
							name: "Preferences", callBack: "onClickPreferences" 
   
   				menu Edition
						label : "Edition"
						items : 
							name: "Copy", callBack: "onCopy" 
							name: "Paste", callBack: "onPaste" 
*/

// Q1
type menuItem = { menuLabel: string, callBack: string}[];

type menu = { menuName: string, menuItems: menuItem }

// Q2

// File
let menuFile: menu = {
	menuName: "File",
	menuItems: [
		{menuLabel: "Save...", callBack: "onClickSave"},
		{menuLabel: "Open...", callBack: "onClickOpen"},
		{menuLabel: "Preferences", callBack: "onClickPreferences"}
	]
}

// Edition
let menuEdition: menu = {
	menuName: "Edition",
	menuItems: [
		{menuLabel: "Copy", callBack: "onCopy"},
		{menuLabel: "Paste", callBack: "onPaste"}
	]
}