export class A{
    aa(){
        console.log("Hello A");
    }
}