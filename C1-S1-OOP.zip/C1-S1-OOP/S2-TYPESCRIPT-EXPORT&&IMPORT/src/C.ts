

console.log("Hello C");
