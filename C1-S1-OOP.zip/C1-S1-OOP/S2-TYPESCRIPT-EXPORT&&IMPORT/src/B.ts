import {A} from "./A"

let ObA = new A;

ObA.aa()