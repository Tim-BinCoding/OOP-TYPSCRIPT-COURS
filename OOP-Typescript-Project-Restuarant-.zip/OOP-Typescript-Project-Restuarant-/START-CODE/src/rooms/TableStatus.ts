/**
 * The different status of a bed
 */
export enum TableStatus {
  GOOD,
  OPERATIONAL,
  BROKEN,
}
