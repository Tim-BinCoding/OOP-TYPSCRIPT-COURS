

import { Customer } from "../human/customer/Customer";
import { Room } from "./Room";

export class RoomsManager {
  public rooms: Room[] = [];
  getNumberOfRooms(): number {
    return this.rooms.length;
  }
  addRoom(room: Room) {
    return this.rooms.push(room);
  }

}
