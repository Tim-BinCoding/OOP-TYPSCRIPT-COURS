

// MAIN ----------------
class Mailbox {
    private Mails:Mail[]=[]
    constructor(private name: string){}
    addMail(...mail:Mail[]){
        this.Mails = this.Mails.concat(mail);
    }

    getMails():Mail[]{
        return this.Mails;
    }
}

abstract class Mail {
    constructor(protected title:string, protected body:string){}
}

class ReceivedMail extends Mail{
    private fromUser:User;
    constructor(private receiveDate:string, title:string, body:string){
        super(title, body);
    }
}
class SentMail extends Mail {
    private toUser:User;
    constructor(private sentDate:string, title:string, body:string){
        super(title, body);
    }
}
class User {
    constructor(public firstName:string, public lastName:string){}
}
