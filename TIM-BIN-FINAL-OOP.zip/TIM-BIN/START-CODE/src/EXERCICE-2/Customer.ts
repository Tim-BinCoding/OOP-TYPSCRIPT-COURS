import { Book } from "./Book";
import { Date } from "./Date";
import { Widthdraw } from "./Widthdraw";

export class Customer {
    public draws:Widthdraw[];
    constructor(
        private firstName:string,
        private lastName:string
    ){}

    addDrawBook(...draw:Widthdraw[]){
        this.draws=this.draws.concat(draw);
    }

    getNumberDraws():number{
        return this.draws.length;
    }

    removeDraw(){
        for (let index = 0; index < this.draws.length; index++) {
            if(this.draws[index]){
                this.draws[index].draw="";
            }
            
        }
    }
}
