export class Date {
    constructor(private mount:string, private year:number){}
}
