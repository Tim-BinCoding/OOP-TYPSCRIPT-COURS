import { Address } from "./Address";
import { Book } from "./Book";
import { Category } from "./Category";
import { Customer } from "./Customer";
import { Date } from "./Date";
import { Widthdraw } from "./Widthdraw";

export class Library {
    private books:Book[]=[];
    private drawBooks:[{Book:Book, Customer:Customer, Date_withdraw:Date}];
    constructor(private name:string, address:Address){}

    addBook(book:Book){
        if(!this.bookExited(book)){
            this.books.push(book);
        }
    }

    bookExited(book:Book): boolean{
        let isEqual=false
        for(let book of this.books){
            if(book.isEqual(book)){
                isEqual=true
            }
        }
        return isEqual;
    }

    getBooks():Book[]{
        return this.books;
    }

    withdrawBook(bookDraw:Book, customer:Customer, date:Date):boolean{
        let isOperation=true
        for(let book of this.books){
            if(book.isEqual(bookDraw)){
                this.drawBooks.push({"Book":bookDraw, "Customer":customer, "Date_withdraw": date})
            }
        }
        if(this.drawBooks.length<0){
            isOperation=false
        }
        return isOperation;
    }

    removeBookWithdraw(book:Book){
        for (let index = 0; index < this.drawBooks.length; index++) {
            const bookDraw = this.drawBooks[index];
            if(bookDraw.Book===book && bookDraw.Customer.getNumberDraws()>0){
                bookDraw.Customer.removeDraw()
                return book;
            }
        }
    }

    isBookAvailable(book:Book):boolean{
        let isAvaible=false
        for (let index = 0; index < this.drawBooks.length; index++) {
            let bookdraw = this.drawBooks[index];
            if(bookdraw.Book===book && bookdraw.Customer.getNumberDraws()==0){
                isAvaible=true
            }
        }
        return isAvaible;
    }

    getBookFor(category:Category):Book[]{
        let listBooks:Book[]=[]
        for(let book of this.books){
            let categories=book.getCategories();
            for(let cate of categories){
                if(category===cate){
                    listBooks.push(book);
                }
            }
        }
        return listBooks;
    }


}
