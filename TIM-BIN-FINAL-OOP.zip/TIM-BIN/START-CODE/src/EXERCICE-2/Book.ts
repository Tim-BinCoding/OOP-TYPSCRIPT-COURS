import { Category } from "./Category";
import { Widthdraw } from "./Widthdraw";

export class Book {
    private categories:Category[]=[];
    constructor(
        private title:string, 
        private author:string,
        private price:number
    ){}
    addCategoy(...category:Category[]){
        this.categories = this.categories.concat(category)
    }

    getCategories():Category[]{
        return this.categories;
    }

    isEqual(other:Book):boolean{
        if(this.title===other.title&&this.author===other.author){
            return true
        }
        return false;
    }
}
