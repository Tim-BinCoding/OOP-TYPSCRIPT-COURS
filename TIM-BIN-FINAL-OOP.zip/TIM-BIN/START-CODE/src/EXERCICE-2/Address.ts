
export class Address {
    constructor(private street:string, private city:string){}
}
