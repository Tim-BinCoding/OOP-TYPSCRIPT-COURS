export enum Category {
    OOP="OOP",
    SONG="SONG",
    CRAZY="CRAZY",
    IT="IT",
    TYPESCRIPT="TYPESCRIPT"
}
