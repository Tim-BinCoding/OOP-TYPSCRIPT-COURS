

export class Widthdraw {
    constructor(public draw:string){}
}
