import { Disease } from "../../medical/Disease";
import { Gender } from "../Person";
import { Person } from "../Person";

/**
 * A patient is a personn with some heath issues
 */
export class Patient extends Person {
  private diseases: Disease[] = [];

  constructor(name: string, age: number, gender: Gender) {
    super(name, age, gender);
  }

  addDisease(disease: Disease) {
    this.diseases.push(disease);
  }

  isEqual(other:Patient) : boolean {
    if(this.name == other.name && this.age == other.age && this.gender == other.gender){
      return true;
    }
    return false;
  }
}
