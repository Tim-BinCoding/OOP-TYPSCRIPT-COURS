
import { Staff, StaffCategory } from "./Staff";
import { Disease } from "../../medical/Disease";
import { Gender, Person } from "../Person";

/**
 * A doctor is a staff with a mediacal speciality
 */
export class Doctor extends Staff {
  private speciality?: Disease;

  constructor(category:StaffCategory,name: string, age: number, gender: Gender) {
    super(category,name, age, gender);
  }

  hasSpeciality(): boolean {
    return this.speciality !== undefined;
  }

  setSpeciality(speciality: Disease) {
    this.speciality = speciality;
  }

  getSpeciality() {
    return this.speciality;
  }

  isEqual(other:Doctor):boolean{
    if(this.category == other.category && this.name == other.name && this.age == other.age && this.gender == other.gender){
      return true
    }else{return false}
  }

}
