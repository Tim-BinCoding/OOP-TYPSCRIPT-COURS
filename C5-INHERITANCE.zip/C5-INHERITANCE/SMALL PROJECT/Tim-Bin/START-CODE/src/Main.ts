// TEST THE MODEL HERE
import { CalendarManager } from "./calendar/CalendarManager";
import { DateTime } from "./calendar/DateTime";
import {EventCategory} from "./calendar/Event"
import { DoctorAppointment } from "./calendar/DoctorAppointment";
import { Doctor } from "./human/staff/Doctor"
import { Nurse } from "./human/staff/Nurse"
import { Disease } from "./medical/Disease";
import { HumanManager } from "./human/HumanManager";
import { Hospital } from "./Hospital";
import { Room } from "./rooms/Room";
import { RoomsManager } from "./rooms/RoomsManager";
import { Bed } from "./rooms/Bed";
import { Patient } from "./human/patient/Patient";
import {Gender}  from"./human/Person";
import { StaffCategory } from "./human/staff/Staff";

let newHospital = new Hospital("CheySab Hospital", "SaArng, Cheysan, PVH, str 112");
let room1 = new Room(1);
let room2 = new Room(2);
let bed1 = new Bed(1);
let bed2 = new Bed(2);
let bed3 = new Bed(3);
let bed4 = new Bed(4);

// add bed to each room
room1.addBed(bed1)
room1.addBed(bed3)
room2.addBed(bed2)
room2.addBed(bed4)

// set patient to eacroom
let rady = new Patient("Rady", 28, Gender.MALE);
let jeene = new Patient("JEENE", 28, Gender.FEMALE);
bed1.setPatient(rady);
bed2.setPatient(jeene);

// add doctor
let him = new Doctor(StaffCategory.DOCTOR, "Him", 22, Gender.MALE);
him.setSpeciality(Disease.STOMACH);
newHospital.hr.addStaff(him)
// add nurse
let ronan = new Nurse("Ronan", 39, Gender.MALE);

// date time
let start = new DateTime(14, 3, 2022, 8);
let end = new DateTime(14, 3, 2022, 10);
let freeTime = new DateTime(15, 3, 2022, 12);
let Appointment1 = new DoctorAppointment(EventCategory.DOCTOR_APPOINTEMENT, start, end, him, jeene)
let Appointment2 = new DoctorAppointment(EventCategory.DOCTOR_APPOINTEMENT, end, freeTime, him, jeene)
// console.log("appointment doctor: ", Appointment1);

// Calendar manager
let calendar = new CalendarManager()
calendar.addEvent(Appointment1);
calendar.addEvent(Appointment2)


//add room to new hospital
let roomManager = new RoomsManager();
roomManager.addRoom(room1)
roomManager.addRoom(room2)
newHospital.rooms = roomManager;

// humanManager
let humanManager = new HumanManager()

// console.log("Doctor: ", newHospital.hr);

// console.log("appointment ", calendar.getAllAppointementFor(him));

console.log("Are you free ? : ", calendar.isDoctorFree(freeTime, him));

console.log("Remove patient from bed 1: ", roomManager.findFreeRoom());


