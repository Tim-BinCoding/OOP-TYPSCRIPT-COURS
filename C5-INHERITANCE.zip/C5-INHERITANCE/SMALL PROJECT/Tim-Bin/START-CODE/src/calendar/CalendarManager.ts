import { Doctor } from "../human/staff/Doctor";
import { DateTime } from "./DateTime";
import { DoctorAppointment } from "./DoctorAppointment";
import { Event } from "./Event";

export class CalendarManager {
  public events: Event[] = [];

  addEvent(event: Event) {
    this.events.push(event);
  }

  /**
   * @returns all appointement for the given doctor
   */
  getAllAppointementFor(doctor: Doctor): DoctorAppointment[] {
    let appointementFrees:DoctorAppointment[]=[]
    for(let event of this.events){
      let appointement = event as DoctorAppointment;
      if(doctor.isEqual(doctor) && appointement.getDoctor()){
        appointementFrees.push(appointement)
      }
    }
    return appointementFrees;
  }

  /**
   *
   * @returns true if the doctor is free at given date (no appointement) - false otherwise
   */
  isDoctorFree(date: DateTime, doctor:Doctor): Boolean {
    let message = false
    let allAppointments = this.getAllAppointementFor(doctor);
    for(let appointment of allAppointments){
      if(appointment.getStartTime()!= date && appointment.getEndTime()!= date){
        message = true
      }
    }
    return message;
    
  }
}
