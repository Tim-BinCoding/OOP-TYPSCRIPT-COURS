/**
 * All hospital managed diseases types
 */
export enum Disease {
  STOMACH = "Stomach",
  CANCER = "Cancer", 
  EYES = "Eyes",
  TEETH = "Teeth",
  EAR = "Ear",
  NOSE = "Nose"
}
