
import { Patient } from "../human/patient/Patient";
import { Room } from "./Room";
export class RoomsManager {
  public rooms: Room[] = [];
  getNumberOfRooms(): number {
    return this.rooms.length;
  }
  addRoom(room: Room) {
    return this.rooms.push(room);
  }

  /** Find a room with a free bed
   * @return the first room available with a free bed
   */
   findFreeRoom(): Room | undefined {
    let freeRooms:Room[]=[];
    this.rooms.forEach(room => {
      let beds = room.getBeds();
      beds.forEach(bed => {
        if(!bed.hasPatient()){
          freeRooms.push(room);
        }
      });
    });
    if(freeRooms.length > 0){
      return freeRooms[0];
    }
      return undefined;
  }
  
  removePatient(patient:Patient){
    this.rooms.forEach(room => {
      let beds = room.getBeds();
      beds.forEach(bed => {
        if(bed.getPatient()?.isEqual(patient)){
          bed.removePatientFromBed(patient)
        }
      });
    });
  }
}
