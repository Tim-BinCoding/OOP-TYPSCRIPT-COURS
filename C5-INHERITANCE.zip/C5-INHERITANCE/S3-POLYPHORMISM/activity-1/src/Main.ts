

import { OrageJuice } from "./OrangeJuice";
import { Coffee } from "./Coffee";

let orage = new OrageJuice(2, "OG", 2400);

let coffee = new Coffee(4, "Coffee bar", 400);

console.log(orage);

console.log(coffee);

