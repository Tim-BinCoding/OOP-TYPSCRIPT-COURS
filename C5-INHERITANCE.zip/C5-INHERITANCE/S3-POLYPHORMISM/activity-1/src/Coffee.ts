import { Drink } from "./Drink";
export class Coffee extends Drink{
    constructor(public sugar:number, name:string, price:number){
        super(name, price);
    }	
};