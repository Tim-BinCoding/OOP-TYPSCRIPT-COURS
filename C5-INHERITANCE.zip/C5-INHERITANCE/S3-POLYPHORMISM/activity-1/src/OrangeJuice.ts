import { Drink } from "./Drink";

export class OrageJuice extends Drink{
    constructor(public numOfOrange:number, name:string, price:number){
        super(name, price);
    }	
}