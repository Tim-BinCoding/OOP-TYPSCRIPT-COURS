
export class Gender{
    constructor(private gender:string){}
}

export abstract class Person{
    public gender:Gender;
    constructor(
        protected id:number,
        protected name:string,
        protected age:number,
        protected phone:number
        ){}
}

class Staff extends Person{
    constructor(
        id:number, name:string, 
        age:number, phone:number,
        private salary:number
        ){
        super(id, name, age, phone);
    }
}

class Patient extends Person{
    constructor(
        id:number, name:string, 
        age:number, phone:number,
        ){
        super(id, name, age, phone);
    }
}

class Disease{
    constructor(
        private CANCER:String, 
        private EAR:String, 
        private NOSE:String, 
        private EYES:String, 
        private patient:Patient
        ){}
}

class Doctor extends Staff{
    constructor(
        id:number, name:string, 
        age:number, phone:number,
        salary:number
        ){
        super(id, name, age, phone, salary);
    }
}

class Nurse extends Staff{
    constructor(
        id:number, name:string, 
        age:number, phone:number,
        salary:number
        ){
        super(id, name, age, phone, salary);
    }
}

