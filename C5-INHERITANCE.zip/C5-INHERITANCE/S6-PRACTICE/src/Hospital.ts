
export class  Hospital {
    constructor(protected name:string, protected address:string) {}
}