
export class RoomManager{
    Rooms:Room[];
    setRooms(...room:Room[]){
        this.Rooms=this.Rooms.concat(room)
    }
}

class Room{
    beds:bed[];
    constructor(private id:number){}
    setBeds(...bed:bed[]){
        this.beds=this.beds.concat(bed)
    }
}

class bed{
    public bedStatus:string;
    constructor(private id:number){}
}

