

class Mailbox {
    private mails:Mail[];
    constructor(private name:string){}
}
abstract class Mail {
    constructor(private title:string, private body:string){};
}

 class ReceivedMail extends Mail{
    constructor(private receivedDate:string, title:string, body:string, receiv:User){
        super(title, body);
    }
 }

class SentMail extends Mail{
    constructor(private sentDate:string, title:string, body:string, private to:User){
        super(title, body);
    }
}
class User {
    constructor(private firstname:string, private lastname:string){}
}

// MAIN ----------------
