class Address {}
class Customer {}
class Room {}
class Hotel {}

// MAIN ----------------
