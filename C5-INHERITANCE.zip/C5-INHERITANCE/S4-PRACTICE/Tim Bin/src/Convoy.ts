import { Vehicles } from "./Vehicle";

export class VehicleConvoys{
    public listOfVehicles:Vehicles[]=[];

    addVehicle(...vehicle:Vehicles[]){
        this.listOfVehicles = this.listOfVehicles.concat(vehicle);
    }

    getMaxSpeed():number{
        let max:number=this.listOfVehicles[0].getSpeed();
        for (let index = 0; index < this.listOfVehicles.length; index++) {
            const element = this.listOfVehicles[index];
            if(element.getSpeed() < max){
                max = element.getSpeed()
            }
        }
        return max;
    }

}