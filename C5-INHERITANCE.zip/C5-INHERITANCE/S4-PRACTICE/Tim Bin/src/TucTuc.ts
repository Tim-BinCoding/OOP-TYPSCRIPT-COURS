
import { Vehicles } from "./Vehicle";

export class TucTuc extends Vehicles{
    private speed:number=130;
    constructor(
        plateID:string, weight:number, 
        private numberCustomer:number
        ){
            super(plateID, weight);
        }
    getSpeed(): number {
       
        return this.speed - this.numberCustomer*5;
    }
}