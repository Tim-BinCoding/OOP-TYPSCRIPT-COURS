
export abstract class  Vehicles {
    constructor(private plateID:string, private weight:number) {}
    abstract getSpeed():number;
}