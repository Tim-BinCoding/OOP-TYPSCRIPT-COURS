
import { Vehicles } from "./Vehicle";

export class BatMobile extends Vehicles{
    private speed:number=110;
    constructor(
        plateID:string, weight:number, 
        private isBatmanHere:boolean, 
        ){
        super(plateID, weight);
    }
    getSpeed(): number {
        if(this.isBatmanHere){
            this.speed=500;
        }
        return this.speed;
    }
}