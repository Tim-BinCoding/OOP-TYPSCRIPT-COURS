
import { Vehicles } from "./Vehicle";

export class MiniVan extends Vehicles{
    private speed:number=130
    constructor( 
        plateID:string, weight:number, 
        private numberCustomer:number, 
        private numberLuggage:number)
        {
            super(plateID, weight);
        }
    getSpeed(): number {
        return this.speed - this.numberCustomer*10 - this.numberLuggage*5;
    }
}