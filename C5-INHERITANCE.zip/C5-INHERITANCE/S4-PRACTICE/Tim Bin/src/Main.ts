import { VehicleConvoys } from "./Convoy";
import { BatMobile } from "./BatMobile";
import { MiniVan } from "./MiniVan";
import { TucTuc } from "./TucTuc";

let batMobile = new BatMobile("BatMobile", 350, true)
let minivan = new MiniVan("SamYong", 230, 3, 4)
let tuctuc = new TucTuc("Tuc Tuc", 400, 2)

let convoy= new VehicleConvoys()
convoy.addVehicle(batMobile);
convoy.addVehicle(minivan);
convoy.addVehicle(tuctuc);

console.log("BatMobile speed is " + batMobile.getSpeed() +" KM");
console.log("Minivan speed is "+ minivan.getSpeed()+" KM");
console.log("TucTuc speed is "+ tuctuc.getSpeed()+" KM");

console.log("The max speed of Vehicle is "+ convoy.getMaxSpeed()+" KM");
