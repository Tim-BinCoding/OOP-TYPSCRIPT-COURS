
// class Person {
//     name:string;
//     address:string;
//     constructor(name:string, address:string){
//         this.name = name;
//         this.address = address;
//     }
    
// }


// class  Employee extends Person {
//     salary:number;
//     constructor(_name:string, _address:string, _salary:number) {
//         super(_name, _address);
//         this.salary = _salary;
//     }
// }

// let ronan = new Employee("Ronan", "paris", 400)

// console.log(ronan);
