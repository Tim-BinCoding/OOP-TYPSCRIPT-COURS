import { Point } from "./Point";

export class ColoredPoint extends Point {
  constructor(x: number, y: number) {
    super(x, y);
  }

  /**
   * Depending on the point position:
   * - if x= 0 => green
   * - else if y= 0 => red
   * - else => yellow
   * @returns the color of the point
   */
  getColor(): string {
    if (this.pointX() == 0 ){
      return "green";
    }else if(this.pointY() == 0){
      return "red";
    }else{
      return "Yellow";
    }
  }
}
