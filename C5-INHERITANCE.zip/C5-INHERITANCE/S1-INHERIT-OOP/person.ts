

class Person{
    name:string;
    age:number;
    constructor(name:string, age:number){
        this.name = name;
        this.age = age;
    }
}

class Teacher extends Person{
    School:string;
    Teach:string
    constructor(_name:string, _age:number, school:string, Teach:string){
        super (_name, _age);
        this.School = school;
        this.Teach = Teach;
    }
}

let him = new Teacher("Him", 20, "PNC", "OOP")

console.log(him);
