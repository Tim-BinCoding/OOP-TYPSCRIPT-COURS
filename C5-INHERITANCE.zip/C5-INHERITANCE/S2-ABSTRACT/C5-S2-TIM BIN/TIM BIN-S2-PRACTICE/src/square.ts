
import { Shape } from "./shape";

export class Square extends Shape {
    private size:number;
    constructor(actX:number, actY:number, size:number){
        super(actX, actY);
        this.size = size;
    }
    
    getWidth(): number {
        return this.size;
    }

    getHeight(): number {
        return this.size;
    }

    getArea(): number {
        return this.getWidth()*this.getHeight();
    }
}

