import { Shape } from "./shape";

export class Rectangle extends Shape {
    rightX:number;
    topY:number;
    constructor(leftX:number, bottomY:number, rightX:number, topY:number){
        super(leftX, bottomY);
        this.rightX = rightX
        this.topY = topY;
    }
    getWidth(): number {
        return this.rightX - this.leftX;
    }
     
    getHeight(): number{
        return this.topY - this.bottomY;
    }
    getArea(): number {
        return this.getWidth()*this.getHeight();
    }
}