
import { Circle } from "./circle";
import { Rectangle } from "./rectangle";
import { Square } from "./square";

let cicle = new Circle(2, 2, 10);
let rectangle = new Rectangle(3, 4, 8, 6);
let square = new Square(2, 4, 10);

console.log(cicle.getArea());
console.log(rectangle.getArea());
console.log(square.getArea());

