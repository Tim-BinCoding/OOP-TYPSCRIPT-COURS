

export abstract class Shape{
    protected leftX:number;
    protected bottomY:number;
    constructor(X:number, Y:number){
        this.leftX = X;
        this.bottomY = Y;
    }
    abstract getWidth(): number;
    abstract getHeight(): number;
    abstract getArea(): number;
}