
abstract class Animal{
    constructor(protected name:string){};
    abstract playSound(): void;
}

class Cat extends Animal{
    playSound(): void {
        console.log("meoow"); 
    }
}

class Dog extends Animal{
    playSound(): void {
        console.log("Woof"); 
    }
}

let dog = new Dog("dog")
let cat = new Cat("Cat")
console.log(dog.playSound(), cat.playSound());

