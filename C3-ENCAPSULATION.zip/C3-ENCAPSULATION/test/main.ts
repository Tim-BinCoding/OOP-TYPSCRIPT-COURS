

class Student {
    constructor(private name:string, private age?: number) {}
  
    isEqual(other: Student): boolean {
      return this.name === other.name && this.age === other.age;
    }
  }
  
  let student1 = new Student("hak", 45);
  let student2 = new Student("hak");
  
  console.log(student1.isEqual(student2));