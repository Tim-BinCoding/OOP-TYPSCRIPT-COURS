// TODO

import { Author } from "./Author";
import { Book } from "./Book";
import { Library } from "./Library";
import { Publisher } from "./Publisher";

let ronan = new Author("Ronan");
let him = new Author("Him");

let Sipa = new Publisher("Sipa", "Phnom Penh")
let IBC = new Publisher("IBC", "Siep Reap")

let bookOop= new Book("OOP is the best", "2018")
bookOop.addAuthor(ronan);
bookOop.setPublisher(Sipa);

let bestT = new Book("Best team", "2015")
bestT.addAuthor(ronan);
bestT.setPublisher(Sipa);

let askBook = new Book("The Why not book","2020");
askBook.addAuthor(him);


let pnLibrary = new Library("PNC LIBRARY", "Phnom Penh");
pnLibrary.addBook(bookOop);
pnLibrary.addBook(bestT);
pnLibrary.addBook(askBook);

console.log(pnLibrary.getBooks(ronan));


