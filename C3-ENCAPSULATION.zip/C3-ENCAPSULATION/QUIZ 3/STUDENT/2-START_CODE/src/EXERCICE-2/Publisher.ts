// TODO

export class Publisher{
    private name:string;
    private address:string;
    constructor(n:string, add:string){
        this.name = n;
        this.address = add;
    }
}