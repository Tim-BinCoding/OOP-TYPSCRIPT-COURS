// TODO
import { Author } from "./Author";
import { Publisher } from "./Publisher";
export class Book{
    private title:string;
    private year:string;
    public authors:Author[]=[];
    public publisher?:Publisher;
    constructor(text:string, year:string){
        this.title = text;
        this.year = year;
    }

    addAuthor(Author:Author){
        this.authors.push(Author);
    }
    setPublisher(publisher:Publisher){
        this.publisher = publisher;
    }
}