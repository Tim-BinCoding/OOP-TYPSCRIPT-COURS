// TODO
import { Book } from "./Book";
import { Author } from "./Author";
import { Publisher } from "./Publisher";

export class Library{
    private name:string;
    private address:string;
    listBooks:Book[]=[];
    constructor(n:string, add:string){
        this.name = n;
        this.address = add;
    }
    addBook(aBook:Book){
        this.listBooks.push(aBook);
    }

    getBooks(author:Author){
        let books:Book[]=[];
        let bookAuthors = this.listBooks
        for (let index = 0; index < bookAuthors.length; index++) {
            let elements = bookAuthors[index].authors;
            for (let i = 0; i < elements.length; i++) {
                if(elements[i]["name"]){
                    // bookAuthors.push(elements[i]["name"])
                }
                
            }
        }
        return bookAuthors;
        
    }

    getBooksByPub(apublish:Publisher){
        let books:Book[]=[];
        // let publisher
    }

}

