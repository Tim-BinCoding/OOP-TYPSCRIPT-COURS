
class Customer {
    constructor(private firstName: string, private lastName: string, private address: Address){}
    public isEqual(other: Customer): boolean{
        let customerIsbooked = false;
        if (this.firstName == other.firstName && 
            this.lastName == other.lastName &&  
            other.address.isEqual(other.address) == this.address.isEqual(other.address)){
            customerIsbooked = true;
        }
        return customerIsbooked;
    }
    
    public setAddress(address: Address){
        this.address = address;
    }
}

class Address {
    constructor(public city: string, public country: string, public street: number){}
    public isEqual(other:Address):boolean{
        let hasAlready = false;
        if(this.city == other.city && this.country == other.country && this.street == other.street){
            hasAlready = true
        }
        return hasAlready;
    }
}

class Room {
    private customer: Customer[]=[];
    constructor(private id:number, public numberOfBed:number){}
    public bedIsFull():boolean{
        if (this.customer.length <= this.numberOfBed){
            return true;
        }else{
            return false;
        }
    }
    public hasCustomer(newCustomer: Customer):boolean{
        for(let customer of this.customer){
            if(customer.isEqual(newCustomer)){
                return true;
            }
        }
        return false;
    } 
    public addCustomer(customer:Customer){
        if (this.bedIsFull() && !this.hasCustomer(customer)){
            this.customer.push(customer);
        }
    }
    public getCustomer(){
        return this.customer;
    }
}

class Hotel{
    private rooms:Room[]=[];
    private customers:Customer[] = [];
    constructor(private address: Address, private name: string){}
    public customerIsInHotel(newCustomer : Customer) : boolean{
        let customers = this.customers
        for (let customer of customers) {
            if (customer.isEqual(newCustomer)){
                return true;
            }
        }
        return false;
    }

    public registerCustomer(customer : Customer, room: Room) : boolean{
        if(!this.customerIsInHotel(customer) && room.bedIsFull()){
            room.addCustomer(customer);
            this.customers.push(customer);
            return true
        }
        return false;
    }
    public addRoom(room : Room) {
        this.rooms.push(room);
    }
}

let address1 = new Address('PVH', "Cambodia", 62);
let address2 = new Address('SR', "Cambodia", 72);

let Vichet = new Customer('Vichet',"Morm", address1);
let Sarath = new Customer('Sarath',"Orn", address2);

let room1 = new Room(1, 4);
room1.addCustomer(Vichet);
room1.addCustomer(Sarath);
let room2 = new Room(1, 2);
room2.addCustomer(Vichet);
room2.addCustomer(Sarath);

let hotel1 = new Hotel(address1, "Nga");
hotel1.addRoom(room1);

hotel1.registerCustomer(Vichet, room1);
hotel1.registerCustomer(Sarath, room2);
console.log(hotel1);