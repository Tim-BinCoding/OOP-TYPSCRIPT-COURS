
import { Student } from "./SCHOOL";

import{ Classroom } from "./SCHOOL";

import { School } from "./SCHOOL";
// CREATE STUDENTS
let Khey = new Student("Khey", "Parth");

let sarath = new Student("Sarath", "Orn");

let Vichet = new Student("Vichet", "Morm");

let hak = new Student("Hak", "Kim");

// CREATE SCHOOL
let samkySchool=new School("Chear Sim Samkey School");
let meanCheySchool=new School("Tbaeng MeanChey School")
// CREATE CLASSROOM
let classroom1 = new Classroom(samkySchool, "22B");
let classroom2 = new Classroom(meanCheySchool, "23B")

//ADD STUDENT
classroom1.addStudent(Khey);
classroom1.addStudent(Vichet)
classroom1.addStudent(sarath);
classroom1.addStudent(hak)

// ADD CLASSROOM
samkySchool.addClassroom("B21")

console.log(classroom1);


