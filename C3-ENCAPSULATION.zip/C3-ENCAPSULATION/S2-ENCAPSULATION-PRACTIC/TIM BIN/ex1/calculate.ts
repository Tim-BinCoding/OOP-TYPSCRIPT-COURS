
class Person{
    private name: string
    private yearOfBirth: number
    constructor(name: string, yob: number) {
        this.name = name
        this.yearOfBirth=yob
    }
    getName(): string{
        return this.name
    }
    getYearOfBirth(): number{
        return this.yearOfBirth
    }
}

class Calendar{
    private currentYear: number
    constructor(currentYear: number) {
        this.currentYear=currentYear
    }
    getAge(person:Person): number{
        return this.currentYear - person.getYearOfBirth()
    }
}

let nga = new Person("Nga", 2000);
let tim = new Person("Tim", 1998);
let today = new Calendar(2022);

console.log(today.getAge(nga));

