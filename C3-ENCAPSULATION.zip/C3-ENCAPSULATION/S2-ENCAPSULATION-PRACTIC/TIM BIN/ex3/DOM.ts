
class DomElement{
    private name: string
    parent?: DomElement
    children:DomElement[]=[]
    constructor(name: string) {
        this.name=name
    }
    getName(){
        return this.name;
    }
    isRoot():boolean {
        return this.parent==undefined
    }
    addChildren(child: DomElement) {
        this.children.push(child)
    }
    setParent(parent: DomElement) {
        this.parent=parent
    }
    getNumberOfChilds(): number {  
        for(let i = 0; i < this.children.length; i++){
          console.log("child: " + this.children[i].children.length);
        }
        return 0; // TODOS
      }
}

let html = new DomElement('html');
let head = new DomElement('head');
let body = new DomElement('body');
let title = new DomElement('title');
let a = new DomElement('a');
let h1 = new DomElement('h1');

html.addChildren(head);
html.addChildren(body);
head.setParent(html);
body.setParent(html);
title.setParent(head);
a.setParent(body);
h1.setParent(body);

console.log(html);
