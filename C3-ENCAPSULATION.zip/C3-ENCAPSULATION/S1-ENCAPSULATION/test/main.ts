

// Private: for make security that not allow someone to acess data depend on.

// Public: for allow someone can access data whatever.